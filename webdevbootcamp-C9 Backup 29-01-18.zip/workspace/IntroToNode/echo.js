function echo (str, num) {
    for(var i = 0; i < num; i++){
      console.log(str);
    }
}

echo("Echo!!!", 10)
echo("Tater Tots", 3)