#Using Node

* Interact with the Node console (node)
* Run a file with node (node <filename>)  Needs to end with .js