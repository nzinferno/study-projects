var cat = require("cat-me");
var joke = require("knock-knock-jokes");
console.log(cat());

console.log(joke());

