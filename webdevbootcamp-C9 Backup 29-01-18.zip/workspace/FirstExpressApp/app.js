var express = require("express");
var app = express();

// First Route
// "/" => "Hi There!"
app.get("/", function(req, res){
    res.send("Hi there!");
});

//  "/bye" => "Goodbye!"
app.get("/bye", function(req, res){
    res.send("Goodbye!!");
});
//  "/dog" => "Meow!"
app.get("/dog", function(req,res){
    console.log("Someone made a request to /dog");
   res.send("Meow!"); 
});

app.get("/r/:subReddit", function(req,res){
    console.log("Someone made a request to /r/");
   res.send("Welcome to a subreddit"); 
});

app.get("*", function(req,res){
   res.send("YOU ARE A STAR!!!");
});
// Listen for requests

app.listen(process.env.PORT, process.env.IP, function(){
    console.log("Server has started!!");
});